CREATE TRIGGER `add`
AFTER INSERT ON orders
FOR EACH ROW
  BEGIN 
	update user set user_num=user_num+1 where user_id=NEW.user_id;
END;
