CREATE VIEW goodsview AS
  SELECT
    `xcx`.`goods`.`id`           AS `id`,
    `xcx`.`goods`.`name`         AS `name`,
    `xcx`.`goods`.`prices`       AS `prices`,
    `xcx`.`goods`.`origin`       AS `origin`,
    `xcx`.`goods`.`num`          AS `num`,
    `xcx`.`goods`.`show`         AS `show`,
    `xcx`.`map_class_id`.`class` AS `class`
  FROM (`xcx`.`goods`
    JOIN `xcx`.`map_class_id` ON ((`xcx`.`map_class_id`.`id` = `xcx`.`goods`.`id`)));
